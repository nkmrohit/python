from django.apps import AppConfig


class AuthuserConfig(AppConfig):
    name = 'authUser'
