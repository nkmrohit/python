from django.db import models

# Create your models here.
def __str__(self):
    return self.name  