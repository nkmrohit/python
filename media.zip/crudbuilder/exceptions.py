class AlreadyRegistered(Exception):
    pass


class NotModelException(Exception):
    pass


class NotRegistered(Exception):
    pass


class CrudModuleNotExit(Exception):
    pass
