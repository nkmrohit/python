from django.apps import AppConfig


class CustomerauthConfig(AppConfig):
    name = 'customerauth'
