from django.apps import AppConfig


class AdminauthConfig(AppConfig):
    name = 'adminauth'
